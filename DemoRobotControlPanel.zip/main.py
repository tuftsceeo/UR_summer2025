from pyscript import document, window, when

import channel


myChannel = channel.CEEO_Channel("hackathon", "@chrisrogers", "talking-on-a-channel", divName = 'all_things_channels', suffix='_test')


import asyncio
from js import document

async def wait_and_hide():
    '''
    hide some elements
    '''
    selectors = [
        "#title_test",
        "#send_test",
        "#payload_test",
        "#channelValue_test",
    ]
    while True:
        if len(selectors) < 1:
            document.querySelector("#all_things_channels > table > tbody > tr > td:nth-child(5)").remove()
            document.querySelector("#activity_test").style.width = "fit-content"
            break
        for selector in selectors:
            elements = document.querySelectorAll(selector)
            if elements.length > 0:
                for el in elements:
                    el.style.display = "none"
                selectors.remove(selector)

asyncio.create_task(wait_and_hide())
