# URarm Control Panel
NOTE: this page is a copy of the URarm Control Panel with some features removed. It is intended to be used remotely for the final demo for arm projects in Summer 2025

This page can move the UR arm and connect up the tools for impact testing.
## Channel Setup
* connect button to connect to channels
* Auto Populate Topic button:
    * if light is green, the topic that the current Jupyter notebook code (see github) expects will fill in automatically when the move and tool buttons are pressed
    * if light is red current topic in the channel input box will be used
## Bluetooth Setup
* connect button to connect to ble devices
* Start Code button (NOT CURRENTLY FUNCTIONAL)
    * starts the code with callbacks to communicate between connected ble device and channel
* Show Code button
    * brings up pop-up with the serial IDE and ble to channels code. press "load code" buttons to see and run default code
## Tool Controls
* Hit Hammer button
     * sends message over channels to activate the hammer
* Probe button
    * sends message over channels to activate probe
## Robot Control Panel
* Central Buttons
    * send a message over channels to move the robot in the indicated direction
* Move Delta input:
    * distance in mm that the move buttons will make the hammer move. Can input ints or floats
* Gripper Control
    * opens / closes the gripper the correct size for the impact testing tool