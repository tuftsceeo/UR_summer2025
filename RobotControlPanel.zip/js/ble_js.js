export class BLEDevice {
    constructor() {
        this.device = null;
        this.server = null;
        this.service = null;
        this.writeCharacteristic = null;
        this.notifyCharacteristic = null;
        this.callback = null;
        this.disconnectCallback = null;
    }

    async connect(serviceUUID, writeUUID, notifyUUID) {
        try {
            this.device = await navigator.bluetooth.requestDevice({
                filters: [{ services: [serviceUUID] }]
            });
            this.handleDisconnect = this.handleDisconnect.bind(this);
            this.device.addEventListener('gattserverdisconnected', this.handleDisconnect);
            
            this.server = await this.device.gatt.connect();
            this.service = await this.server.getPrimaryService(serviceUUID);
            this.writeCharacteristic = await this.service.getCharacteristic(writeUUID);
            this.notifyCharacteristic = await this.service.getCharacteristic(notifyUUID);
            this.handleNotification = this.handleNotification.bind(this);
            await this.notifyCharacteristic.startNotifications();
            this.notifyCharacteristic.addEventListener('characteristicvaluechanged',
                this.handleNotification);
            return true;
        } catch (error) {
            console.error('Error connecting:', error);
        }
    }

    handleNotification(event) {
        const value = event.target.value;
        const data = new Uint8Array(value.buffer);
        if (this.callback) {this.callback(data)};
    }

    handleDisconnect(event) {
        console.log('Device disconnected');
        if (this.disconnectCallback) {
            console.log('run callback');
            this.disconnectCallback(event);
        }
    }

    async write(data) {
        if (!this.writeCharacteristic) {
            console.error('Not connected to device');
            return;
        }
        try {
            const bytes = new Uint8Array(data);
            await this.writeCharacteristic.writeValue(bytes);
            //console.log('Sent:', bytes);
        } catch (error) {
            console.error('Error writing:', error);
        }
    }

    disconnect() {
        if (this.device && this.device.gatt.connected) {
            this.device.gatt.disconnect();
        }
    }
}

//export const myBLE = new BLEDevice();
//export function createBLEDevice() {
//    return new BLEDevice();}