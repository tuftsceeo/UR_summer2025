# URarm Control Panel
This page can move the UR arm and connect up the tools for impact testing.
## Connect to Robot (Channel Setup)
* connect button to connect to channels
* Auto Populate Topic button:
    * if light is green, the topic that the current Jupyter notebook code (see github) expects will fill in automatically when the move and tool buttons are pressed
    * if light is red current topic in the channel input box will be used
## Tool Setup
* Defaults to serial setup
* Serial Connect button
    * connects to devices over serial port
* Start Code button
    * loads either serial or ble code and starts it
* Show Code button
    * brings up pop-up with the serial IDE and ble to channels code. press "load code" buttons to see and run default code
* Connection Mode
    * defaults to serial, press to switch to ble
    * determines what code will load in the code editor (from Load Code buttons) and what code the Start Code button will run
## Tool Controls
* Hit Hammer button
     * sends message over channels to activate the hammer
* Probe button
    * sends message over channels to activate probe
## Robot Control Panel
* Central Buttons
    * send a message over channels to move the robot in the indicated direction
* Move Delta input:
    * distance in mm that the move buttons will make the hammer move. Can input ints or floats
* Gripper Control
    * opens / closes the gripper the correct size for the impact testing tool
* Corner Placement
    * records the current position of the robot. Recommended to extend probe for exact positioning
    * corner 1 assumes that the current position of the probe is the location first impact point
    * corner 3 should be the opposite corner (diagonal from the starting corner, probe centered on final impact point)
        * height is irrelevant for corner 3, corner 1's position should be recorded with the probe hovering around 1 mm above the plate
    * after both corners have been selected the Jupyter code only listens for the start button
* Points
    * input for the impact grid size
        * ex) an input of 4 will assume a 4x4 grid of points
    * the start button is grayed out until both corners have been set
        * start button sends a message over channels telling the robot to start the test (probe the plate then do the hits)