hammersensor_serial = '''import time
from machine import Pin, PWM
import json

class Count(object):
    def __init__(self,A,B):
        self.A = A
        self.B = B
        self.counter = 0
        A.irq(self.cb,self.A.IRQ_FALLING|self.A.IRQ_RISING) #interrupt on line A
        B.irq(self.cb,self.B.IRQ_FALLING|self.B.IRQ_RISING) #interrupt on line B

    def cb(self,msg):
        other,inc = (self.B,1) if msg == self.A else (self.A,-1) #define other line and increment
        self.counter += -inc if msg.value()!=other.value() else  inc #XOR the two lines and increment
        
    def value(self):
        return self.counter
                
    def reset(self):
        self.counter = 0

class Motor():
    def __init__(self, name):
        # motor inits
        self.m1 = Pin(26, Pin.OUT)
        self.m2 = Pin(27, Pin.OUT)
        self.running = False
        self.hit_counter = 1
        self.encoder = Count(Pin(28, Pin.IN), Pin(29, Pin.IN))
        self.error = 0
        self.first_run = True

        # sensor inits
        self.motor = Pin(0)
        self.inPin = Pin(7, Pin.IN)
        self.inPin_state = self.inPin.value()
        self.ready = False
        self.value = False

    def grabData(self):
        if self.running:
            if self.value:
                message = {"motor_status": "running", "sensor_status": "sensed"}
            else:
                message = {"motor_status": "running", "sensor_status": "sensing"}
        else:
            if self.value:
                message = {"motor_status": "not_running", "sensor_status": "sensed"}
            else:
                message = {"motor_status": "not_running", "sensor_status": "sensing"}
        return str(json.dumps(message))

    def run_motor(self):
        self.m1.value(1)
        while self.encoder.value() < 8200 - self.error:
            pass
        self.m1.value(0)
        self.running = False
        time.sleep(0.5)
        self.error = self.encoder.value() - 8200
        print(self.encoder.value(), self.error)
        if self.first_run:
            self.error = (self.encoder.value() - 8200) * 2
            self.first_run = False
        self.encoder.reset()
        print("motor done running")


    def deploy(self):
        pwm = PWM(self.motor)
        pwm.freq(50)
        pwm.duty_u16(2000)
        time.sleep(0.2)
        pwm.duty_u16(0)
        pwm.deinit()

    def retract(self):
        pwm = PWM(self.motor)
        pwm.freq(50)
        pwm.duty_u16(5000)
        time.sleep(0.2)
        pwm.duty_u16(0)
        pwm.deinit()

    def sense(self):  
        while True:
            if self.inPin.value() != 0:
                self.value = False
                break

    def run_sensor(self):
        self.deploy()
        self.sense()
        self.retract()
        self.ready = False
        self.value = True
        print("sensed")


motor = Motor('esp32_URarm')'''

channel_serial_code = '''import json
buffer = ''
async def repl_callback(event):
    global buffer
    buffer += event
    if '\\r\\n' in buffer:
        fred = buffer.split('\\r\\n')
        buffer = fred[-1]
        if '===' in fred[0] or '>>>' in fred[0]:
            return
        if "motor done running" in fred:
            msg = {"motor_status": "not_running", "sensor_status": "sensed"}
            await myChannel.post('/modal/tool/request/response',str(json.dumps(msg)))
        elif "sensed" in fred:
            msg = {"motor_status": "not_running", "sensor_status": "sensed"}
            await myChannel.post('/modal/tool/request/response',str(json.dumps(msg)))

async def channel_callback(message):
    topic, value = myChannel.check('/modal/tool/request',message)
    if topic and value:
        if value == "hit":
            msg = {"motor_status": "running", "sensor_status": "sensed"}
            await myChannel.post('/modal/tool/request/response',str(json.dumps(msg)))
            myRS232.uboard.board.write('motor.run_motor()')
            myRS232.uboard.board.write('\\r\\n')
        elif value == "probe":
            msg = {"motor_status": "not_running", "sensor_status": "sensing"}
            await myChannel.post('/modal/tool/request/response',str(json.dumps(msg)))
            myRS232.uboard.board.write('motor.run_sensor()')
            myRS232.uboard.board.write('\\r\\n')

myChannel.callback = channel_callback
myRS232.uboard.newData_callback = repl_callback'''

hammersensor_code = '''import time
from machine import Pin, PWM
from BLE_CEEO import Yell, Listen
import json

class Count(object):
    def __init__(self,A,B):
        self.A = A
        self.B = B
        self.counter = 0
        A.irq(self.cb,self.A.IRQ_FALLING|self.A.IRQ_RISING) #interrupt on line A
        B.irq(self.cb,self.B.IRQ_FALLING|self.B.IRQ_RISING) #interrupt on line B

    def cb(self,msg):
        other,inc = (self.B,1) if msg == self.A else (self.A,-1) #define other line and increment
        self.counter += -inc if msg.value()!=other.value() else  inc #XOR the two lines and increment
        
    def value(self):
        return self.counter
                
    def reset(self):
        self.counter = 0

class Motor():
    def __init__(self, name):
        # motor inits
        self.m1 = Pin(0, Pin.OUT)
        self.m2 = Pin(1, Pin.OUT)
        self.running = False
        self.hit_counter = 1
        self.encoder = Count(Pin(21, Pin.IN), Pin(22, Pin.IN))
        self.error = 0

        # sensor inits
        self.motor = Pin(16)
        self.inPin = Pin(23, Pin.IN)
        self.inPin_state = self.inPin.value()
        self.ready = False
        self.value = False
        self.p = Yell(name, interval_us=30000, verbose = False)

    def grabData(self):
        if self.running:
            if self.value:
                message = {"motor_status": "running", "sensor_status": "sensed"}
            else:
                message = {"motor_status": "running", "sensor_status": "sensing"}
        else:
            if self.value:
                message = {"motor_status": "not_running", "sensor_status": "sensed"}
            else:
                message = {"motor_status": "not_running", "sensor_status": "sensing"}
        return str(json.dumps(message))


    def callback(self, data):
        print(data.decode())
        if data.decode() == "hit":
            if self.running == False:
                self.running = True
        if data.decode() == "probe":
            if self.ready == False:
                self.ready = True

    def run_motor(self):
        self.p.send(self.grabData())
        print('r')
        time.sleep(0.1)
        self.m1.value(1)
        while self.encoder.value() < 8192 * self.hit_counter:
            pass
        self.m1.value(0)
        self.running = False
        self.hit_counter += 1
        if self.hit_counter == 10:
            time.sleep(0.5)
            self.encoder.reset()
            self.m1.value(1)
            while self.encoder.value() < 400:
                pass
            self.m1.value(0)
            self.hit_counter = 1
            self.encoder.reset()

    def deploy(self):
        pwm = PWM(self.motor)
        pwm.freq(50)
        pwm.duty_u16(2000)
        time.sleep(0.2)
        pwm.duty_u16(0)
        print("deployed")
        pwm.deinit()

    def retract(self):
        pwm = PWM(self.motor)
        pwm.freq(50)
        pwm.duty_u16(5000)
        time.sleep(0.2)
        pwm.duty_u16(0)
        print("retracted")
        pwm.deinit()

    def sense(self):  
        while True:
            if self.inPin.value() != 0:
                self.value = False
                break

    def run_sensor(self):
        self.deploy()
        self.sense()
        self.retract()
        self.ready = False
        self.value = True
        
    def peripheral(self): 
        try:
            print('waiting ...')
            #sensor.skip_frames(time=2000)
            if self.p.connect_up():
                self.p.callback = self.callback
                print('Connected')
                time.sleep(1)
                while self.p.is_connected:
                    self.p.send(self.grabData())
                    time.sleep(0.1)
                    if self.running:
                        self.run_motor()
                    if self.ready:
                        self.value = False
                        self.p.send(self.grabData())
                        self.run_sensor()
                print('lost connection')
        except Exception as e:
            print('Error: ',e)
        finally:
            self.m1.value(0)
            self.p.disconnect()
            print('closing up')


motor = Motor('esp32_URarm')
motor.peripheral()

'''

channel_ble_code = '''import json
import asyncio 

prev_value = None
hit = 0
probe = 0

async def myCallback(message):
    global prev_value
    value = json.loads(message.decode())
    if value != prev_value:
        print(value)
        prev_value = value
        await myChannel.post('/modal/URarm/tool/response', value)

def fred(message):
    global hit
    global probe
    topic, value = myChannel.check('/modal/tool/request', message)
    if topic and value:
        print('Success: ', topic, value)
        if value == 'hit':
            hit = 1
    topic, value = myChannel.check('/modal/tool/request', message)
    if topic and value:
        print('Success: ', topic, value)
        if value == 'probe':
            probe = 1


# Setup callbacks
myBle.callback = myCallback
myChannel.callback = fred

print("Loop starting")
while True:
    await asyncio.sleep(1)
    if hit:
        print("sending ble command")
        await myBle.send_str('hit')
        hit = 0
    if probe == 1:
        print("sending ble command")
        await myBle.send_str('probe')
        probe = 0
print("done running")     
'''