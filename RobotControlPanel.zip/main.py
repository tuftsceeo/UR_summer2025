from pyscript import document, window, when

import channel, ble, RS232


myChannel = channel.CEEO_Channel("hackathon", "@chrisrogers", "talking-on-a-channel", divName = 'all_things_channels', suffix='_test')
myBle = ble.CEEO_BLE(divName = 'all_things_ble')
myRS232 = RS232.CEEO_RS232(divName = 'all_things_rs232', suffix = '1', myCSS = True)

@when("click", "#loadcode")
def on_loadHammerSensorcode(event):
    from myCode import hammersensor_code
    myRS232.python.code = hammersensor_code

python_area = document.getElementById('PC_code')
@when("click", "#loadcode_2")
def on_loadChannelBleCode(event):
    from myCode import channel_ble_code
    python_area.code = channel_ble_code

#hammer code won't auto load for some reason
#on_loadHammerSensorcode(None)
on_loadChannelBleCode(None)

import asyncio
from js import document

async def wait_and_hide():
    '''
    hide some elements
    '''
    selectors = [
        "#title1",
        "#title_test",
        "#send_test",
        "#payload_test",
        "#channelValue_test",
        "#all_things_ble > table > tbody > tr > td:nth-child(4)",
        "#send1",
        "#payload1"
    ]
    while True:
        if len(selectors) < 1:
            document.querySelector("#all_things_channels > table > tbody > tr > td:nth-child(5)").remove()
            document.querySelector("#activity_test").style.width = "fit-content"
            document.querySelector("#activity1").style.width = "fit-content"
            document.querySelector("#name1").textContent = "myBle"
            break
        for selector in selectors:
            elements = document.querySelectorAll(selector)
            if elements.length > 0:
                for el in elements:
                    el.style.display = "none"
                selectors.remove(selector)

asyncio.create_task(wait_and_hide())
