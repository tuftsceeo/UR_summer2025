from pyscript import document, window, when

import channel, ble, RS232
import asyncio
from js import document, setTimeout

myChannel = channel.CEEO_Channel("hackathon", "@chrisrogers", "talking-on-a-channel", divName = 'all_things_channels', suffix='_test')
myBle = ble.CEEO_BLE(divName = 'all_things_ble')
myRS232 = RS232.CEEO_RS232(divName = 'all_things_rs232', suffix = '1', myCSS = True)

@when("click", "#loadcode")
def on_loadHammerSensorcode(event):
    from myCode import hammersensor_code, hammersensor_serial
    if (document.getElementById("tool_mode").innerHTML == "Connection Mode: Serial"):
        myRS232.python.code = hammersensor_serial
    else:
        myRS232.python.code = hammersensor_code

python_area = document.getElementById('PC_code')
@when("click", "#loadcode_2")
def on_loadChannelBleCode(event):
    from myCode import channel_ble_code, channel_serial_code
    if (document.getElementById("tool_mode").innerHTML == "Connection Mode: Serial"):
        python_area.code = channel_serial_code
    else:
        python_area.code = channel_ble_code



def click_editor_button():
    editor = document.getElementById("mpy-editor-0")
    if editor:
        btn = editor.querySelector("button")
        if btn:
            btn.click()
            return
    setTimeout(click_editor_button, 200)

@when("click", "#start_code_button")
def on_start_code(event):
    click_editor_button()


async def wait_and_hide():
    '''
    hide some elements
    '''
    selectors = [
        "#title1",
        "#title_test",
        "#send_test",
        "#payload_test",
        "#channelValue_test",
        "#all_things_ble > table > tbody > tr > td:nth-child(4)",
        "#send1",
        "#payload1"
    ]
    while True:
        if len(selectors) < 1:
            document.querySelector("#all_things_channels > table > tbody > tr > td:nth-child(5)").remove()
            document.querySelector("#activity_test").style.width = "fit-content"
            document.querySelector("#activity1").style.width = "fit-content"
            document.querySelector("#name1").textContent = "myBle"
            document.querySelector("#topic_test").value = "/modal"
            break
        for selector in selectors:
            elements = document.querySelectorAll(selector)
            if elements.length > 0:
                for el in elements:
                    el.style.display = "none"
                selectors.remove(selector)

asyncio.create_task(wait_and_hide())
