from pyscript import window, document
from pyscript.js_modules import ble_js
import asyncio

SERVICE_UUID = '0000fd02-0000-1000-8000-00805f9b34fb'
WRITE_UUID   = '0000fd02-0001-1000-8000-00805f9b34fb'
NOTIFY_UUID  = '0000fd02-0002-1000-8000-00805f9b34fb'

BLECode = '''    
<h3 id = 'title{num}'>BLE Setup</h3>
  <table>
    <tr>
        <td><button id = "sync{num}">Connect</button></td>
        <td><div id = 'live{num}' style="background-color: red; width: 10px; height: 10px; border-radius: 5px; display: inline-block;"></div> </td>
        <td id = 'name{num}'> myBle =  </td>
        <td style="width: 100px; text-align: center"><label id = "value{num}">0</label></td>
        <td><input id = 'payload{num}' maxlength = 50 type='text' value = 'send this'></td>
        <td><button id = "send{num}">Send</button></td>
    </tr></table>
    <div style = 'color:#0000FF; width: 800px' id = "activity{num}"></div>
'''

class CEEO_BLE():
    def __init__(self, divName, suffix = '1', serviceUUID = SERVICE_UUID, writeUUID = WRITE_UUID, notifyUUID = NOTIFY_UUID):
        self.myble = myBLE = ble_js.BLEDevice.new()
        self.suffix = suffix
        self.blediv = document.getElementById(divName)
        self.blediv.innerHTML = BLECode.format(num = suffix)
        self.callback = None
        self.myble.callback = self.onmessage
        self.myble.disconnectCallback = self.disconnect_callback
        self.S_UUID, self.W_UUID, self.N_UUID = serviceUUID, writeUUID, notifyUUID
        
        
        self.payload = document.getElementById('payload%s'%suffix)
        self.send = document.getElementById('send%s'%suffix)
        self.send.onclick = self.send_it
        self.id = document.getElementById('sync%s'%suffix)
        self.id.onclick = self.ask
        self.liveBtn = document.getElementById('live%s'%suffix)
        self.liveBtn.style.backgroundColor = 'red'
        
    def onmessage(self, data):
        message = bytes(data) #[d for d in data]
        document.getElementById('activity%s'%self.suffix).innerHTML = str(message)
        if self.callback:
            if str(type(self.callback)).find('generator') != -1:
                await self.callback(message)
            else:
                self.callback(message)

    def disconnect_callback(self, event):
        window.console.log('lost connection')
        self.id.innerHTML = 'Connect'
        self.liveBtn.style.backgroundColor = 'red'
        
    async def ask(self, event):
        if self.liveBtn.style.backgroundColor == 'red':
            await self.connect()
        else:
            self.disconnect()
            
    async def connect(self):
        success = await self.myble.connect(self.S_UUID, self.W_UUID, self.N_UUID)
        if success:
            self.id.innerHTML = 'Disconnect'
            window.console.log('connected')
            self.liveBtn.style.backgroundColor = 'green'

    def disconnect(self):
        self.id.innerHTML = 'Connect'
        self.myble.disconnect()
        window.console.log('disconnected')
        self.liveBtn.style.backgroundColor = 'red'
        
    async def write(self, data):
        await self.myble.write(data)

    async def send_str(self, datastring):
        await self.write([d for d in datastring.encode()])

    async def send_it(self, event):
        if self.id.innerHTML == 'Connect':
            return
        await self.send_str(str(self.payload.value))


